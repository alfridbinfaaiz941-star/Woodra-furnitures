# Woodra Furnitures

Next.js starter for the Woodra furniture store.

Run: `npm install` then `npm run dev`.

Add environment variables from `.env.example` when connecting Supabase and Razorpay. Never commit secret keys.