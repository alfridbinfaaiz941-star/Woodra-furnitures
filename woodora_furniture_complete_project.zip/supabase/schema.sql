-- Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create type public.user_role as enum ('customer','admin');
create type public.order_status as enum ('pending','confirmed','processing','shipped','delivered','cancelled');
create type public.payment_status as enum ('created','paid','failed','refunded');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role public.user_role not null default 'customer',
  created_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique,
  description text,
  category text not null,
  price_inr numeric(12,2) not null check(price_inr >= 0),
  stock integer not null default 0 check(stock >= 0),
  image_url text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id),
  total_inr numeric(12,2) not null check(total_inr >= 0),
  status public.order_status not null default 'pending',
  payment_status public.payment_status not null default 'created',
  razorpay_order_id text unique,
  razorpay_payment_id text,
  created_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity integer not null check(quantity > 0),
  unit_price_inr numeric(12,2) not null check(unit_price_inr >= 0)
);

create table public.addresses (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id) on delete cascade,
  label text,
  full_name text not null,
  phone text not null,
  line1 text not null,
  line2 text,
  city text not null,
  state text not null,
  postal_code text not null,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.addresses enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin') $$;

create policy "public can view active products" on public.products for select using (active=true or public.is_admin());
create policy "admins manage products" on public.products for all using(public.is_admin()) with check(public.is_admin());

create policy "users view own profile" on public.profiles for select using(id=auth.uid() or public.is_admin());
create policy "users update own profile" on public.profiles for update using(id=auth.uid());
create policy "admins manage profiles" on public.profiles for all using(public.is_admin()) with check(public.is_admin());

create policy "users view own orders" on public.orders for select using(customer_id=auth.uid() or public.is_admin());
create policy "users create own orders" on public.orders for insert with check(customer_id=auth.uid());
create policy "admins manage orders" on public.orders for all using(public.is_admin()) with check(public.is_admin());

create policy "users view own order items" on public.order_items for select using(exists(select 1 from public.orders o where o.id=order_id and (o.customer_id=auth.uid() or public.is_admin())));
create policy "admins manage order items" on public.order_items for all using(public.is_admin()) with check(public.is_admin());

create policy "users manage own addresses" on public.addresses for all using(customer_id=auth.uid() or public.is_admin()) with check(customer_id=auth.uid() or public.is_admin());

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$ begin insert into public.profiles(id) values(new.id); return new; end $$;

create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

insert into public.products(name,slug,description,category,price_inr,stock,image_url) values
('Luna 3-Seater Sofa','luna-sofa','Soft contemporary sofa for living rooms.','Living',24999,10,'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1200&q=80'),
('Oak Coffee Table','oak-coffee-table','Minimal solid-wood coffee table.','Living',7999,20,'https://images.unsplash.com/photo-1532372320572-cda25653a26d?auto=format&fit=crop&w=1200&q=80'),
('Royal King Bed','royal-king-bed','Modern king-size bed frame.','Bedroom',32999,8,'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1200&q=80'),
('Bedside Table','bedside-table','Compact bedside table with storage.','Bedroom',4999,15,'https://images.unsplash.com/photo-1532372320572-cda25653a26d?auto=format&fit=crop&w=1200&q=80'),
('6-Seater Dining Set','six-seater-dining','Dining table and six chairs.','Dining',28999,6,'https://images.unsplash.com/photo-1617806118233-18e1de247200?auto=format&fit=crop&w=1200&q=80'),
('Executive Office Chair','executive-chair','Ergonomic office chair.','Office',8999,12,'https://images.unsplash.com/photo-1505843490701-5be3e4b3f2e4?auto=format&fit=crop&w=1200&q=80');
