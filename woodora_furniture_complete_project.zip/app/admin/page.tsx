import {requireAdmin} from "../../lib/admin";
export default async function Admin(){
 let data:any; try{data=await requireAdmin();}catch(e:any){return <main className="section"><div className="wrap"><h1>Admin dashboard</h1><div className="notice danger">{e.message==="Forbidden"?"Admin access required.":"Please log in."}</div></div></main>}
 const {supabase}=data; const [{data:products},{data:orders}]=await Promise.all([
  supabase.from("products").select("*").order("created_at",{ascending:false}),
  supabase.from("orders").select("*").order("created_at",{ascending:false}).limit(100)
 ]);
 return <main className="section"><div className="wrap"><h1>Admin dashboard</h1>
 <div className="adminnav"><span className="btn alt">Products: {products?.length||0}</span><span className="btn alt">Recent orders: {orders?.length||0}</span></div>
 <div className="panel"><h2>Products</h2><table className="table"><thead><tr><th>Name</th><th>Price</th><th>Stock</th><th>Active</th></tr></thead><tbody>{(products||[]).map((p:any)=><tr key={p.id}><td>{p.name}</td><td>₹{Number(p.price_inr).toLocaleString("en-IN")}</td><td>{p.stock}</td><td>{p.active?"Yes":"No"}</td></tr>)}</tbody></table></div>
 <div className="panel"><h2>Orders</h2><table className="table"><thead><tr><th>ID</th><th>Total</th><th>Status</th><th>Payment</th></tr></thead><tbody>{(orders||[]).map((o:any)=><tr key={o.id}><td>{o.id.slice(0,8)}</td><td>₹{Number(o.total_inr).toLocaleString("en-IN")}</td><td>{o.status}</td><td>{o.payment_status}</td></tr>)}</tbody></table></div>
 </div></main>;
}
