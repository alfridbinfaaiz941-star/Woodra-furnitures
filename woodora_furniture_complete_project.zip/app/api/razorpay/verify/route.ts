import {NextResponse} from "next/server"; import crypto from "crypto"; import {supabaseServer} from "../../../../lib/supabase-server";
export async function POST(req:Request){
 const {razorpay_order_id,razorpay_payment_id,razorpay_signature,store_order_id}=await req.json();
 const s=await supabaseServer(); const {data:{user}}=await s.auth.getUser(); if(!user)return NextResponse.json({error:"Unauthorized"},{status:401});
 const {data:order}=await s.from("orders").select("*").eq("id",store_order_id).eq("customer_id",user.id).single();
 if(!order||order.razorpay_order_id!==razorpay_order_id)return NextResponse.json({error:"Invalid order"},{status:400});
 const expected=crypto.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET!).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest("hex");
 if(!crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(razorpay_signature)))return NextResponse.json({error:"Invalid signature"},{status:400});
 await s.from("orders").update({payment_status:"paid",status:"confirmed",razorpay_payment_id}).eq("id",store_order_id);
 return NextResponse.json({ok:true});
}
