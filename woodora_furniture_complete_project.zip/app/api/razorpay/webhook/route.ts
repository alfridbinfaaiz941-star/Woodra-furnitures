import {NextResponse} from "next/server"; import crypto from "crypto"; import {supabaseServer} from "../../../../lib/supabase-server";
export async function POST(req:Request){
 const raw=await req.text(); const sig=req.headers.get("x-razorpay-signature")||"";
 const expected=crypto.createHmac("sha256",process.env.RAZORPAY_WEBHOOK_SECRET!).update(raw).digest("hex");
 if(!sig||!crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(sig)))return NextResponse.json({error:"Invalid webhook"},{status:400});
 const event=JSON.parse(raw); const orderId=event?.payload?.order?.entity?.receipt; const s=await supabaseServer();
 if(event.event==="order.paid"&&orderId) await s.from("orders").update({payment_status:"paid",status:"confirmed"}).eq("id",orderId);
 if(event.event==="payment.failed"&&orderId) await s.from("orders").update({payment_status:"failed"}).eq("id",orderId);
 return NextResponse.json({received:true});
}
