import {NextResponse} from "next/server";
import Razorpay from "razorpay";
import {supabaseServer} from "../../../../lib/supabase-server";

export async function POST(req:Request){
 try{
  const body=await req.json(); const productId=String(body.productId); const quantity=Math.max(1,Math.min(20,Number(body.quantity||1)));
  const s=await supabaseServer(); const {data:{user}}=await s.auth.getUser();
  if(!user)return NextResponse.json({error:"Login required"},{status:401});
  const {data:p}=await s.from("products").select("id,name,price_inr,stock,active").eq("id",productId).single();
  if(!p||!p.active||p.stock<quantity)return NextResponse.json({error:"Product unavailable"},{status:400});
  const total=Number(p.price_inr)*quantity;
  const {data:order,error}=await s.from("orders").insert({customer_id:user.id,total_inr:total,status:"pending",payment_status:"created"}).select().single();
  if(error)throw error;
  const razorpay=new Razorpay({key_id:process.env.RAZORPAY_KEY_ID!,key_secret:process.env.RAZORPAY_KEY_SECRET!});
  const rpOrder=await razorpay.orders.create({amount:Math.round(total*100),currency:"INR",receipt:order.id,notes:{store_order_id:order.id}});
  await s.from("orders").update({razorpay_order_id:rpOrder.id}).eq("id",order.id);
  return NextResponse.json({orderId:rpOrder.id,keyId:process.env.RAZORPAY_KEY_ID,amount:rpOrder.amount,currency:rpOrder.currency,storeOrderId:order.id});
 }catch(e){return NextResponse.json({error:"Unable to create payment order"},{status:500});}
}
