 "use client";
import {useState} from "react";
export default function CheckoutButton({productId}:{productId:string}){
 const [loading,setLoading]=useState(false);
 async function buy(){
   setLoading(true);
   const r=await fetch("/api/razorpay/create-order",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({productId,quantity:1})});
   const d=await r.json(); if(!r.ok){alert(d.error||"Please sign in first.");setLoading(false);return;}
   alert("Razorpay order created: "+d.orderId+"\\nAdd the Razorpay Checkout script/client UI here using the returned public key. This starter intentionally never exposes the secret key.");
   setLoading(false);
 }
 return <button className="btn" onClick={buy} disabled={loading}>{loading?"Creating secure order…":"Buy now"}</button>;
}
