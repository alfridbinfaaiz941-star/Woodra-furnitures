import { supabaseServer } from "../../../lib/supabase-server";
import Image from "next/image";
import CheckoutButton from "./checkout-button";

export default async function Product({params}:{params:Promise<{id:string}>}){
  const {id}=await params; const supabase=await supabaseServer();
  const {data:p}=await supabase.from("products").select("*").eq("id",id).eq("active",true).single();
  if(!p) return <main className="section"><div className="wrap"><h1>Product not found</h1></div></main>;
  return <main className="section"><div className="wrap">
    <div className="panel" style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:30}}>
      {p.image_url && <Image className="photo" src={p.image_url} alt={p.name} width={900} height={700}/>}
      <div><p className="muted">{p.category}</p><h1>{p.name}</h1><p>{p.description}</p><h2>₹{Number(p.price_inr).toLocaleString("en-IN")}</h2><CheckoutButton productId={p.id}/></div>
    </div>
  </div></main>;
}
