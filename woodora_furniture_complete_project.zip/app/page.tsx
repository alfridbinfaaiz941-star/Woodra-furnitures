import Link from "next/link";
export default function Home(){
  return <main>
    <section className="hero"><div className="wrap">
      <p className="muted">WOODORA FURNITURE</p>
      <h1>Furniture that makes your space feel like home.</h1>
      <p>Shop sofas, beds, dining sets and workspace essentials. Built as a secure, database-backed store ready for Razorpay payments.</p>
      <Link className="btn" href="/shop">Explore furniture</Link>
    </div></section>
  </main>;
}
