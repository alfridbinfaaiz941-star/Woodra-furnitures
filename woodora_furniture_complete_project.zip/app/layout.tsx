import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "Woodora Furniture",
  description: "Modern furniture for beautiful homes."
};

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <>
    <header className="nav">
      <div className="wrap" style={{display:"flex",width:"100%",alignItems:"center",justifyContent:"space-between"}}>
        <Link className="brand" href="/">WOODORA</Link>
        <nav className="navlinks">
          <Link href="/shop">Shop</Link>
          <Link href="/account">Account</Link>
          <Link href="/admin">Admin</Link>
        </nav>
      </div>
    </header>
    {children}
    <footer className="footer"><div className="wrap">© {new Date().getFullYear()} Woodora Furniture</div></footer>
  </>;
}
