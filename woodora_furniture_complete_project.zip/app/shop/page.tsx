import { supabaseServer } from "../../lib/supabase-server";
import Image from "next/image";
import Link from "next/link";

export default async function Shop(){
  const supabase=await supabaseServer();
  const {data:products}=await supabase.from("products").select("*").eq("active",true).order("created_at",{ascending:false});
  return <main className="section"><div className="wrap">
    <h1>Shop furniture</h1>
    <div className="grid">
      {(products||[]).map((p:any)=><article className="card" key={p.id}>
        {p.image_url && <Image className="photo" src={p.image_url} alt={p.name} width={800} height={600}/>}
        <div className="cardbody"><h2>{p.name}</h2><p className="muted">{p.category}</p><p>{p.description}</p><p className="price">₹{Number(p.price_inr).toLocaleString("en-IN")}</p><Link className="btn" href={`/product/${p.id}`}>View product</Link></div>
      </article>)}
    </div>
    {!products?.length && <div className="notice">No products yet. Add products from the admin dashboard after setting up Supabase.</div>}
  </div></main>;
}
