import {supabaseServer} from "../../lib/supabase-server"; import Link from "next/link";
export default async function Account(){
 const s=await supabaseServer(); const {data:{user}}=await s.auth.getUser();
 if(!user)return <main className="section"><div className="wrap"><h1>Your account</h1><p>Please log in to view orders.</p><Link className="btn" href="/login">Log in</Link></div></main>;
 const {data:orders}=await s.from("orders").select("id,status,total_inr,created_at,payment_status").eq("customer_id",user.id).order("created_at",{ascending:false});
 return <main className="section"><div className="wrap"><h1>My account</h1><p className="muted">{user.email}</p><div className="panel"><h2>Orders</h2><table className="table"><thead><tr><th>Order</th><th>Status</th><th>Payment</th><th>Total</th></tr></thead><tbody>{(orders||[]).map((o:any)=><tr key={o.id}><td>{o.id.slice(0,8)}</td><td>{o.status}</td><td>{o.payment_status}</td><td>₹{Number(o.total_inr).toLocaleString("en-IN")}</td></tr>)}</tbody></table></div></div></main>;
}
