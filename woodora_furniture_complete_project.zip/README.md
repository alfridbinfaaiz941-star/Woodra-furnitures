# Woodora Furniture — production starter

## Included
- Next.js customer storefront
- Supabase PostgreSQL schema + Row Level Security
- Supabase email/password authentication
- Customer account/order history
- Admin role protection
- Product and order dashboard
- Razorpay Orders API server route
- Razorpay signature verification route
- Razorpay webhook HMAC verification route
- Environment-variable based secrets
- Responsive UI

## Important
This is a production-oriented starter, not a claim that a live merchant account, domain, KYC, database project, or payment account has been activated.

Razorpay secrets must remain server-side. Never commit `.env.local`, API secrets, webhook secrets, service-role keys, or production credentials.

For live payments, an eligible adult/business owner must complete the Razorpay merchant onboarding/KYC and provide the credentials through the deployment provider's encrypted environment-variable settings.

## Local setup
1. Install Node.js 20+.
2. Create a Supabase project.
3. Run `supabase/schema.sql` in the Supabase SQL editor.
4. Copy `.env.example` to `.env.local`.
5. Fill in the Supabase values.
6. Run `npm install`.
7. Run `npm run dev`.
8. Open the local site.

## Make yourself an admin
After creating your first account, run this in Supabase SQL Editor, replacing the email:
```sql
update public.profiles
set role='admin'
where id=(select id from auth.users where email='YOUR-ADULT-OWNER-EMAIL');
```
Do not make public users admins.

## Razorpay
The included server route creates a Razorpay order and returns only the public key ID plus order details. Complete the browser Checkout UI and call `/api/razorpay/verify` after Checkout returns its response. Configure Razorpay webhooks to `/api/razorpay/webhook`.

For production:
- use HTTPS
- validate payment signatures
- keep secrets out of source control
- use webhook HMAC validation
- use Razorpay test mode before live mode
- configure appropriate refund/order-state handling
- do not trust prices sent by the browser; calculate totals from database products server-side

## Deployment
A typical deployment is a Next.js-compatible host plus Supabase. Add the environment variables in the host dashboard, deploy, then connect the custom domain in the host's domain settings. Do not paste secrets into source files.

## Before launch
Add:
- full cart and multi-item checkout
- shipping/address selection at checkout
- tax/GST/invoice logic as applicable to the business
- stock reservation/decrement transaction
- refund workflow
- email/SMS order notifications
- image upload/storage
- admin create/edit/delete product forms
- rate limiting and bot protection
- audit logs
- privacy policy, terms, shipping, returns/refund and contact pages
- business/legal details required for the actual seller
